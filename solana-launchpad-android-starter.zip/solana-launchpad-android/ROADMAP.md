# Roadmap

- [x] Initial Android application skeleton
- [x] Compose discovery, create-preview, and portfolio-preview screens
- [x] Android CI workflow
- [x] Architecture and security baseline documentation
- [ ] Verify CI build and unit tests
- [ ] Add MVVM ViewModels and repository interfaces
- [ ] Add wallet adapter and Devnet-only connection
- [ ] Implement SPL token creation with simulation and wallet approval
- [ ] Add backend API, database, indexing, and moderation
- [ ] Design bonding curve / swap / liquidity system separately
- [ ] Add AdMob with test IDs, consent flow, and policy review
- [ ] Security, legal, and Play Store release preparation

A checked item means files are included in this starter package, not that an external build was executed.

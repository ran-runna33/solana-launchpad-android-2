# Cost estimate

Costs depend on traffic, RPC volume, storage, moderation, and security needs.

Keep the prototype inexpensive: Android Studio/Kotlin/Compose and GitHub free allowances can support early development; use Solana Devnet; select RPC/database free tiers only after checking limits. Production audits, legal advice, infrastructure, and moderation are real operating costs.

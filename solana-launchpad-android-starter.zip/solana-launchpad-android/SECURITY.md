# Security baseline

- Never collect, transmit, log, or store wallet seed phrases or private keys.
- Wallets must display and approve every transaction.
- Default to Devnet while developing.
- Validate token names, symbols, metadata URLs, numeric values, and addresses.
- Simulate transactions and verify post-confirmation state.
- Use idempotency for backend writes and rate-limit public endpoints.
- Keep RPC/API secrets out of the Android app and Git history.
- Add dependency and secret scanning before production.

## Release gates
Threat model, transaction tests, smart-contract audit, privacy policy, terms, risk disclosures, and incident response plan. Mainnet only after explicit owner approval.

Rotate any credential accidentally committed to the repository.

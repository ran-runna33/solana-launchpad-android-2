# Changelog

## 0.1.0 — Foundation
- Kotlin Android app using Jetpack Compose and Material 3.
- Discover, Create preview, and Portfolio preview destinations.
- Static demo token cards with explicit demo-data labeling.
- Android CI workflow and architecture/security documentation.
- No wallet signing, token minting, trading, backend, or advertising is enabled.

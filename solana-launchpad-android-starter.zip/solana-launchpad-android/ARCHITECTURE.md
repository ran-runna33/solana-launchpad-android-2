# Architecture

## Android client
- Kotlin and Jetpack Compose with Material 3.
- Single-activity UI with Discover, Create, and Portfolio destinations.
- UI state is local preview state only in this milestone.
- Planned: MVVM, repositories, coroutines/Flow, and dependency injection.

## Trust boundaries
- Android is an untrusted client.
- Backend must never custody user seed phrases or private keys.
- Solana is the source of truth for token mints and finalized transactions.
- Off-chain services may index public chain data, search, profiles, moderation, and analytics.

## Planned services
1. Wallet adapter with explicit transaction approval.
2. Solana RPC adapter: Devnet first.
3. Indexer/API for metadata, launch state, search, and activity.
4. PostgreSQL for app-owned data; chain remains source of truth.
5. Moderation, rate limits, reporting, and audit logs.

Mainnet requires deliberate release configuration and independent security review.

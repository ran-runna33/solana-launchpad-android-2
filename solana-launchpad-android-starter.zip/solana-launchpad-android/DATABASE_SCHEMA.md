# Database schema — proposed

No database is connected yet. Proposed entities:
- users: internal UUID, public wallet address, created_at; no private key material.
- token_metadata: mint_address, creator_wallet, name, symbol, metadata_uri, moderation_state, created_at.
- chain_transactions: signature, wallet_address, cluster, instruction_type, observed_slot, confirmation_state.
- reports: reporter_wallet, target_mint, reason_code, review_state, created_at.
- audit_events: actor, action, object reference, timestamp.

Verify mint addresses and signatures against the selected Solana cluster.

package com.ranrunna.launchpad

import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectSmokeTest {
    @Test fun appModuleHasAValidPackageName() {
        assertTrue("com.ranrunna.launchpad".contains("."))
    }
}

package com.ranrunna.launchpad

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF151A27)
private val Neon = Color(0xFF9BFF75)
private val Muted = Color(0xFF9AA4B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LaunchpadApp() }
    }
}

private data class TokenPreview(
    val name: String, val ticker: String, val description: String,
    val marketCap: String, val progress: Float, val symbol: String
)

private val sampleTokens = listOf(
    TokenPreview("Moon Raccoon", "MRAC", "Small paws. Big plans.", "$42.8K", .78f, "🦝"),
    TokenPreview("Pixel Frog", "PFRG", "A frog for the digital pond.", "$18.2K", .46f, "🐸"),
    TokenPreview("Cosmic Toast", "TOAST", "To the edge of the breakfast universe.", "$9.6K", .21f, "🍞")
)

@Composable
private fun LaunchpadApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon, secondary = Color(0xFF7DD3FC), background = Ink,
        surface = Panel, onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Discover", "Create", "Portfolio").forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Text(listOf("⌕", "＋", "◈")[index], fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> DiscoverScreen(Modifier.padding(padding))
                1 -> CreateScreen(Modifier.padding(padding))
                else -> PortfolioScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun DiscoverScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("LAUNCHPAD", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Find the next\ncommunity token.", fontSize = 32.sp, lineHeight = 37.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text("Explore early projects on Solana.", color = Muted)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("YOUR NEXT MOVE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Discover. Research. Decide.", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Always do your own research. New tokens can be highly volatile and you can lose your entire investment.",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Trending launches", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        items(sampleTokens) { TokenCard(it) }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun TokenCard(token: TokenPreview) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color(0xFF242D40), shape = RoundedCornerShape(14.dp)) {
                    Text(token.symbol, Modifier.padding(12.dp), fontSize = 25.sp)
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(token.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("$" + token.ticker, color = Muted, fontSize = 12.sp)
                }
                Text(token.marketCap, color = Neon, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text(token.description, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Launch progress", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("${(token.progress * 100).toInt()}%", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(5.dp))
            Surface(color = Color(0xFF30394B), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().height(6.dp)) {
                Surface(color = Neon, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth(token.progress)) {}
            }
            Spacer(Modifier.height(12.dp))
            Text("DEMO DATA · NOT LIVE MARKET INFORMATION", color = Muted, fontSize = 9.sp, letterSpacing = 0.7.sp)
        }
    }
}

@Composable
private fun CreateScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Create a token", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
        Text("Your launch starts with a clear plan.", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp)) {
                Text("TOKEN CREATION IS NOT ENABLED", color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "The next milestone is a secure Devnet token-creation flow with wallet approval, metadata validation, and transaction simulation.",
                    color = Muted
                )
                Spacer(Modifier.height(12.dp))
                Text("No wallet is connected and no transaction will be sent from this preview.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun PortfolioScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Portfolio", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp)) {
                Text("WALLET NOT CONNECTED", color = Neon, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Connect a compatible wallet in a future release. This app will never ask you to enter or share your seed phrase or private key.",
                    color = Muted
                )
            }
        }
    }
}

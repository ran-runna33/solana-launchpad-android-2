# Deployment

## Development
Use JDK 17, Android SDK 35, Gradle 8.9, and Solana Devnet for future chain integration.

## Production gates
Do not publish until wallet flows, transaction simulation, backend security, privacy disclosures, policy compliance, and independent smart-contract review are complete. Mainnet must not be enabled by a debug flag or remotely changed without a controlled release.

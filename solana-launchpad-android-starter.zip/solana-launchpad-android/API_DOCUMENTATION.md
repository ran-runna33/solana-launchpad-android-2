# API documentation

No backend API exists in this milestone. The client currently uses local static preview data.

When introduced, document authentication and wallet-signature challenges, metadata submission and moderation, indexed token and transaction schemas, pagination, rate limits, errors, idempotency, privacy, and abuse-report endpoints.

Never accept private keys or seed phrases in API payloads.

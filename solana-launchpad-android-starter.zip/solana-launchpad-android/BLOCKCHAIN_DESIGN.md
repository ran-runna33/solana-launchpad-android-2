# Blockchain design — planned, not deployed

Evaluate SPL Token and Token-2022 against requirements before selecting a program. Mint creation, metadata, mint authority, freeze authority, and authority revocation must be explicit user-reviewed settings.

## Transaction lifecycle
1. Build from validated user inputs.
2. Simulate on Devnet.
3. Show network, fees, accounts, authorities, and instructions.
4. Request signature through an external wallet.
5. Submit only the signed transaction.
6. Confirm finality and verify mint/account state from RPC.
7. Persist signature and verified chain facts for indexing.

Never request a seed phrase or private key.

## Not implemented
No mint instruction, bonding curve, swap, pool, liquidity lock, or fee-collection program exists yet. Token creation does not automatically create liquidity. Any program controlling funds needs threat modeling, adversarial tests, and independent audit.

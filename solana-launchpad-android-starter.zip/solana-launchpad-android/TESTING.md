# Testing strategy

## Configured CI checks
- `gradle :app:assembleDebug`
- `gradle :app:testDebugUnitTest`

Check the first workflow result before claiming the app builds.

## Planned tests
Compose navigation/accessibility, ViewModel and repository contracts, RPC parsing, transaction simulation and confirmation, backend authorization/rate limiting/idempotency, smart-contract fuzz/invariant tests, and release signing/dependency checks.

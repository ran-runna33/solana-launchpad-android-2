# Solana Launchpad Android

Android-first Solana community-token launchpad foundation built with Kotlin, Jetpack Compose, and Material 3.

## Current status
This is the first Android application foundation and demo discovery UI. Token cards use **static demo data**. Wallet connection, token creation, trading, bonding curves, liquidity, backend services, and AdMob are not implemented.

## Requirements
- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Gradle 8.9

## Build
Open the project in Android Studio and sync Gradle, or run:
```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```
GitHub Actions runs both commands on pushes and pull requests to `main`.

## Safety
- Never enter a seed phrase or private key into this app.
- No Mainnet transactions are implemented.
- Demo token data is not live market data.
- Token creation and liquidity are separate features and require independent design, testing, and security review.

See `ARCHITECTURE.md`, `SECURITY.md`, `BLOCKCHAIN_DESIGN.md`, and `ROADMAP.md`.
